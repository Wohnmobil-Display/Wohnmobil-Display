%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-09-26T15:59:04+02:00*%
%TF.ProjectId,relaisplatine,72656c61-6973-4706-9c61-74696e652e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-09-26 15:59:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,3.200000*%
%ADD11RoundRect,0.250000X-1.050000X-1.050000X1.050000X-1.050000X1.050000X1.050000X-1.050000X1.050000X0*%
%ADD12C,2.600000*%
%ADD13C,2.300000*%
%ADD14R,2.300000X2.300000*%
%ADD15RoundRect,0.249999X0.850001X-0.850001X0.850001X0.850001X-0.850001X0.850001X-0.850001X-0.850001X0*%
%ADD16C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H2*%
X43050000Y19550000D03*
%TD*%
D11*
%TO.C,J3*%
X34050000Y5550000D03*
D12*
X39130000Y5550000D03*
%TD*%
D11*
%TO.C,J1*%
X3350000Y5550000D03*
D12*
X8430000Y5550000D03*
%TD*%
D11*
%TO.C,J2*%
X17050000Y5550000D03*
D12*
X22130000Y5550000D03*
%TD*%
D10*
%TO.C,H1*%
X43050000Y31050000D03*
%TD*%
D13*
%TO.C,K1*%
X17210000Y23050000D03*
D14*
X7050000Y23050000D03*
D13*
X24830000Y23050000D03*
X7050000Y30670000D03*
%TD*%
D15*
%TO.C,D1*%
X3050000Y16550000D03*
D16*
X3050000Y26710000D03*
%TD*%
M02*
